/**
 * Write a description of class CopyOfWeather here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class CopyOfWeather
{
  private String cityName;
  private int [] temps;
  private int numOfTemps;
  
  private static final int MAX_COUNT = 6;
  
  public CopyOfWeather (String name){
      cityName = name;
      temps = new int [MAX_COUNT];
      numOfTemps = 0;
    }
   public String toString (){
       String city = cityName;
       for(int i =0; i <numOfTemps; i++){
           city = city + "\n" + "\t" + temps[i];
        }
        return city;
    }
    private int findIndexToInsert(int temp){
        int index = 0;
        for(int i =0; i < numOfTemps; i++){
            if(temps[i] > temp){
                index = i;
            }
        }
        return index;
    }

public boolean addTempInOrder(int latestTemp){
    
    if(numOfTemps == MAX_COUNT){
            return false;
        }
        int in = numOfTemps;
    for(int i =0; i < numOfTemps; i++){
      if(temps[i] >latestTemp){
          in = i;
          break;
        }
    }
    for(int i = numOfTemps; i > in; i--){
        temps[i] = temps[i -1];
    }
    temps[in] = latestTemp;
    numOfTemps++;
    return true;
}

public int [] calcMeanAndMedian (){
    int median =0;
    if(temps.length % 2 == 0){
        median = (temps[(temps.length/2) -1] + temps[temps.length/2]) /2;
    } else {
        median = temps [temps.length/2];
}
int average = 0;
for(int i =0; i <temps.length; i++){
   average += temps[i];
}
  average += average / temps.length;
 int [] array = new int[] {average, median};
 return array;
}
}

