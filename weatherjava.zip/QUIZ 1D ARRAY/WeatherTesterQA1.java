/**
 * To test the Weather class.
 * 
 * @author Anh Nguyen
 * @version 1.0
 */
public class WeatherTesterQA1
{
    public static void main (String[] args)
    {
        int maxCt = 6;
        int[] meanAndMedian;
        
        System.out.println("\n...........................................................");
        System.out.println("CASE 1:");
        Weather city1 = new Weather("San Francisco");
        int count = maxCt+2, low = 27, high = 105;
        System.out.println("COUNT = " + count + ", from " + low + " to " + high);       

        for (int i = 0; i < count; i++)
        {
            if (! city1.addTempInOrder((int) (Math.random() * (high-low+1)) + low))
            {
                System.out.println("Element beyond capacity not added");
            }
        }
        System.out.println(city1);
        meanAndMedian = city1.calcMeanAndMedian();
        System.out.println("\tMean degrees = " + meanAndMedian[0] + "; Median = " + meanAndMedian[1]);
        

        System.out.println("\n...........................................................");
        System.out.println("CASE 2:");        
        Weather city2 = new Weather("Chicago");
        count = maxCt; low = -50; high = 98;
        System.out.println("COUNT = " + count + ", from " + low + " to " + high);       
        for (int i = 0; i < count-1; i++)
        {
            if (! city2.addTempInOrder((int) (Math.random() * (high-low+1)) + low))
            {
                System.out.println("Element beyond capacity not added");
            }
        }
        city2.addTempInOrder(0);
        System.out.println(city2);
        meanAndMedian = city2.calcMeanAndMedian();
        System.out.println("\tMean degrees = " + meanAndMedian[0] + "; Median = " + meanAndMedian[1]);
        
                
        System.out.println("\n...........................................................");
        System.out.println("CASE 3:");        
        Weather city3 = new Weather("Miami");
        count = maxCt-1; low = 45; high = 109;
        System.out.println("COUNT = " + count + ", from " + low + " to " + high);       
        for (int i = 0; i < count-2; i++)
        {
            if (! city3.addTempInOrder((int) (Math.random() * (high-low+1)) + low))
            {
                System.out.println("Element beyond capacity not added");
            }
        }
        city3.addTempInOrder(low-1);
        city3.addTempInOrder(high+1);
        System.out.println(city3);
        meanAndMedian = city3.calcMeanAndMedian();
        System.out.println("\tMean degrees = " + meanAndMedian[0] + "; Median = " + meanAndMedian[1]);
  
        
        System.out.println("\n...........................................................");
        System.out.println("CASE 4:");        
        Weather city4 = new Weather("Bakersfield");
        count = 1; low = 60; high = 70;
        System.out.println("COUNT = " + count + ", from " + low + " to " + high);       
        for (int i = 0; i < count; i++)
        {
            if (! city4.addTempInOrder((int) (Math.random() * (high-low+1)) + low))
            {
                System.out.println("Element beyond capacity not added");
            }
        }
        System.out.println(city4);
        meanAndMedian = city4.calcMeanAndMedian();
        System.out.println("\tMean degrees = " + meanAndMedian[0] + "; Median = " + meanAndMedian[1]);

        
        System.out.println("\n...........................................................");
        System.out.println("CASE 5:");        
        Weather city5 = new Weather("Pleasanton");
        count = 0; low = 30; high = 100;
        System.out.println("COUNT = " + count + ", from " + low + " to " + high);       
        for (int i = 0; i < count; i++)
        {
            if (! city5.addTempInOrder((int) (Math.random() * (high-low+1)) + low))
            {
                System.out.println("Element beyond capacity not added");
            }
        }
        System.out.println(city5);
        meanAndMedian = city5.calcMeanAndMedian();
        System.out.println("\tMean degrees = " + meanAndMedian[0] + "; Median = " + meanAndMedian[1]);

    }
}